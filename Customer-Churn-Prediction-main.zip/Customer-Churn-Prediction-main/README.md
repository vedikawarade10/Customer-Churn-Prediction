# Customer-Churn-Prediction
Customer Churn Prediction using Machine Learning . Predicts telecom customer likely to leave service using Logistic Regression.
